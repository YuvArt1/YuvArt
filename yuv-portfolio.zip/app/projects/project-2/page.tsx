import Link from "next/link"
import Image from "next/image"
import Footer from "@/components/footer"

export default function Project2Page() {
  return (
    <div className="min-h-screen bg-gray-50 relative">
      {/* Header */}
      <header className="bg-white px-6 py-4">
        <nav className="flex items-center justify-between max-w-7xl mx-auto">
          <Link
            href="/"
            className="text-2xl font-bold text-black hover:text-gray-600 transition-colors font-space-grotesk"
          >
            Yuv
          </Link>
          <div className="flex items-center space-x-8 font-inter">
            <Link href="/work" className="text-black hover:text-gray-600 transition-colors">
              Work
            </Link>
            <Link href="/about" className="text-black hover:text-gray-600 transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-black hover:text-gray-600 transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Project Content */}
      <main className="px-6 py-16 bg-white">
        <div className="max-w-4xl mx-auto">
          {/* Back to Work */}
          <Link
            href="/work"
            className="inline-flex items-center text-gray-600 hover:text-black transition-colors mb-8 font-inter"
          >
            ← Back to Work
          </Link>

          {/* Project Title */}
          <h1 className="text-4xl md:text-6xl font-bold text-black mb-6 font-space-grotesk">Project Two</h1>

          {/* Project Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 font-inter">
            <div>
              <h3 className="font-semibold text-black mb-2 font-space-grotesk">Client</h3>
              <p className="text-gray-700">Tech Innovations Co.</p>
            </div>
            <div>
              <h3 className="font-semibold text-black mb-2 font-space-grotesk">Year</h3>
              <p className="text-gray-700">2024</p>
            </div>
            <div>
              <h3 className="font-semibold text-black mb-2 font-space-grotesk">Services</h3>
              <p className="text-gray-700">UI/UX Design, Animation</p>
            </div>
          </div>

          {/* Project Image */}
          <div className="aspect-video bg-gray-300 rounded-lg overflow-hidden mb-12">
            <Image
              src="/placeholder.svg?height=600&width=1200"
              alt="Project Two"
              width={1200}
              height={600}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Project Description */}
          <div className="prose prose-lg max-w-none font-inter">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              Project Two represents our innovative approach to digital interface design and user experience. Working
              with Tech Innovations Co., we developed a comprehensive design system that enhances user engagement and
              simplifies complex interactions.
            </p>

            <p className="text-gray-700 leading-relaxed mb-6">
              The project required deep understanding of user behavior and technical constraints. We conducted extensive
              research and testing to ensure the final design met both user needs and business requirements.
            </p>

            <p className="text-gray-700 leading-relaxed">
              The implementation resulted in a 40% increase in user engagement and significantly improved the overall
              user experience across all platforms.
            </p>
          </div>

          {/* Navigation */}
          <div className="mt-16 pt-8 border-t border-gray-200 flex justify-between">
            <Link
              href="/projects/project-1"
              className="inline-flex items-center text-gray-600 hover:text-black transition-colors font-inter"
            >
              ← Previous: Project One
            </Link>
            <Link
              href="/projects/project-3"
              className="inline-flex items-center text-black hover:text-gray-600 transition-colors font-inter"
            >
              Next Project: Project Three →
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
