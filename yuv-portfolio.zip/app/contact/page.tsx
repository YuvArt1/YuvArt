import Link from "next/link"
import Image from "next/image"
import Footer from "@/components/footer"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gray-50 relative">
      {/* Header */}
      <header className="bg-white px-6 py-4">
        <nav className="flex items-center justify-between max-w-7xl mx-auto">
          <Link
            href="/"
            className="text-2xl font-bold text-black hover:text-gray-600 transition-colors font-space-grotesk"
          >
            Yuv
          </Link>
          <div className="flex items-center space-x-8 font-inter">
            <Link href="/work" className="text-black hover:text-gray-600 transition-colors">
              Work
            </Link>
            <Link href="/about" className="text-black hover:text-gray-600 transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-black hover:text-gray-600 transition-colors font-semibold">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Contact Content */}
      <main className="px-6 py-16 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Image */}
            <div className="order-2 lg:order-1">
              <div className="aspect-[4/3] bg-gray-300 rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=480&width=640"
                  alt="Contact Yuv"
                  width={640}
                  height={480}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Right side - Contact Links & Details */}
            <div className="order-1 lg:order-2 space-y-8">
              <h1 className="text-4xl md:text-5xl font-bold text-black font-space-grotesk">Contact</h1>

              <div className="space-y-6 font-inter">
                <p className="text-lg text-gray-700 leading-relaxed">
                  Ready to bring your vision to life? Let's start a conversation about your next project.
                </p>

                {/* Email */}
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-black font-space-grotesk">Email</h3>
                  <a
                    href="mailto:hello@yuv.studio"
                    className="text-gray-700 hover:text-black transition-colors text-lg"
                  >
                    hello@yuv.studio
                  </a>
                </div>

                {/* Phone */}
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold text-black font-space-grotesk">Phone</h3>
                  <a href="tel:+1234567890" className="text-gray-700 hover:text-black transition-colors text-lg">
                    +1 (234) 567-890
                  </a>
                </div>

                {/* Social Links */}
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-black font-space-grotesk">Follow Us</h3>
                  <div className="flex flex-col space-y-3">
                    <a
                      href="https://instagram.com/yuv.studio"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-700 hover:text-black transition-colors text-lg"
                    >
                      Instagram
                    </a>
                    <a
                      href="https://behance.net/yuv"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-700 hover:text-black transition-colors text-lg"
                    >
                      Behance
                    </a>
                    <a
                      href="https://dribbble.com/yuv"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-700 hover:text-black transition-colors text-lg"
                    >
                      Dribbble
                    </a>
                    <a
                      href="https://linkedin.com/company/yuv-studio"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-700 hover:text-black transition-colors text-lg"
                    >
                      LinkedIn
                    </a>
                  </div>
                </div>

                {/* Location */}
                <div className="space-y-2 pt-4">
                  <h3 className="text-xl font-semibold text-black font-space-grotesk">Location</h3>
                  <p className="text-gray-700 text-lg">
                    New York, NY
                    <br />
                    Available worldwide
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
