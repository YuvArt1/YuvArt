import Link from "next/link"
import Image from "next/image"
import Footer from "@/components/footer"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50 relative">
      {/* Header */}
      <header className="bg-white px-6 py-4">
        <nav className="flex items-center justify-between max-w-7xl mx-auto">
          <Link
            href="/"
            className="text-2xl font-bold text-black hover:text-gray-600 transition-colors font-space-grotesk"
          >
            Yuv
          </Link>
          <div className="flex items-center space-x-8 font-inter">
            <Link href="/work" className="text-black hover:text-gray-600 transition-colors">
              Work
            </Link>
            <Link href="/about" className="text-black hover:text-gray-600 transition-colors font-semibold">
              About
            </Link>
            <Link href="/contact" className="text-black hover:text-gray-600 transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* About Content */}
      <main className="px-6 py-16 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Large Image */}
            <div className="order-2 lg:order-1">
              <div className="aspect-[4/5] bg-gray-300 rounded-lg overflow-hidden">
                <Image
                  src="/placeholder.svg?height=600&width=480"
                  alt="About Yuv"
                  width={480}
                  height={600}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Right side - Details */}
            <div className="order-1 lg:order-2 space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold text-black mb-8 font-space-grotesk">About</h1>

              <div className="space-y-6 text-gray-700 leading-relaxed font-inter">
                <p className="text-lg">
                  We are a creative studio specializing in motion design, animation, and visual storytelling. Our
                  passion lies in bringing brands to life through compelling visual narratives.
                </p>

                <p>
                  With over a decade of experience in the industry, we've worked with brands of all sizes, from startups
                  to Fortune 500 companies, helping them communicate their message through the power of motion and
                  design.
                </p>

                <p>
                  Our approach combines strategic thinking with creative execution, ensuring that every project not only
                  looks beautiful but also serves its intended purpose effectively.
                </p>

                <div className="pt-4">
                  <h3 className="text-xl font-semibold text-black mb-3 font-space-grotesk">What we do:</h3>
                  <ul className="space-y-2">
                    <li>• Motion Graphics & Animation</li>
                    <li>• Brand Identity & Visual Design</li>
                    <li>• Digital Experiences & Interfaces</li>
                    <li>• Creative Direction & Strategy</li>
                  </ul>
                </div>

                <div className="pt-6">
                  <Link
                    href="/work"
                    className="inline-block bg-black text-white px-8 py-3 rounded-sm hover:bg-gray-800 transition-colors font-inter"
                  >
                    View Our Work
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
